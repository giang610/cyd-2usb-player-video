# ESP32 CYD Video Player

MJPEG video player cho ESP32-2432S028 (Cheap Yellow Display 2USB).

## Cách build ra file .bin

### Lần đầu setup
1. Tạo repo mới trên GitHub (private hoặc public đều được)
2. Upload toàn bộ thư mục này lên repo
3. Vào tab **Actions** → chọn **Build ESP32 Binary** → nhấn **Run workflow**
4. Đợi ~3-5 phút → vào build vừa chạy → kéo xuống **Artifacts**
5. Tải `esp32-cyd-video-player.zip` → giải nén → lấy file `.bin`

### Lần sau (khi sửa code)
Push code lên GitHub → Actions tự build `.bin` mới.

## Dùng với ESP32 Launcher (bmorcelli)
Flash file `.bin` qua launcher như bình thường.

## Cài SD Card
- Tạo thư mục `/mjpeg` trên thẻ SD
- Chép file `.mjpeg` vào đó

## Chỉnh tốc độ phát
```cpp
#define PLAYBACK_SPEED 1.4542f  // Hệ số tốc độ
#define TARGET_FPS     24.0f    // FPS gốc của video
```
